//
//  JZTipLabel.h
//  JZToast
//
//  Created by Jentle on 2017/4/25.
//  Copyright © 2017年 EasyPass. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZTipLabel : UILabel

- (instancetype)initWithText:(NSString *)text;

- (instancetype)initWithText:(NSString *)text textEdgeInsets:(UIEdgeInsets)textInsets maxWidth:(CGFloat)maxWidth minWidth:(CGFloat)minWidth minHeight:(CGFloat)minHeight;


@end
