//
//  JZToastConfig.h
//  JZToast
//
//  Created by Jentle on 2017/4/25.
//  Copyright © 2017年 EasyPass. All rights reserved.
//

#ifndef JZToastConfig_h
#define JZToastConfig_h

typedef enum : NSUInteger {
    JZToastTypeDefault = 0,  //普通文字提示
    JZToastTypeSuccess,      //成功操作提示
    JZToastTypeError,        //错误操作提示
    JZToastTypeWarning       //警告操作提示
} JZToastType;


#endif /* JZToastConfig_h */
