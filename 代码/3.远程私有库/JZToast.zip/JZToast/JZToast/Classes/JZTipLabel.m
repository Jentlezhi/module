//
//  JZTipLabel.m
//  JZToast
//
//  Created by Jentle on 2017/4/25.
//  Copyright © 2017年 EasyPass. All rights reserved.
//

#import "JZTipLabel.h"

#define kBgColor [ColorWithDark(cFF000000, cFF262629) colorWithAlphaComponent:0.7f];
@interface JZTipLabel()


/** 字体内边距 */
@property(assign, nonatomic) UIEdgeInsets textInsets;

/** 最大宽度 */
@property(assign, nonatomic) CGFloat maxWidth;
/** 最小宽度 */
@property(assign, nonatomic) CGFloat minWidth;
/** 最小高度 */
@property(assign, nonatomic) CGFloat minHeight;

@end

@implementation JZTipLabel

- (instancetype)initWithText:(NSString *)text{
    if([self initWithFrame:CGRectZero]){
        self.text = text;
        [self sizeToFit];
    }
    
    return self;
}

- (instancetype)initWithText:(NSString *)text textEdgeInsets:(UIEdgeInsets)textInsets maxWidth:(CGFloat)maxWidth minWidth:(CGFloat)minWidth minHeight:(CGFloat)minHeight{
    if([self initWithFrame:CGRectZero]){
        self.textInsets = textInsets;
        self.maxWidth = maxWidth;
        self.minWidth = minWidth;
        self.minHeight = minHeight;
        self.text = text;
        [self sizeToFit];
    }
    
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if([super initWithFrame:frame]){
        [self tipLabelBasicConfig];
        [self initTipLabelComponents];
        [self makeConstrains];
    }
    
    return self;
}


/**
 *  基本配置
 */
- (void)tipLabelBasicConfig{
    self.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.7f];
    self.numberOfLines = 0;
    self.textAlignment = NSTextAlignmentCenter;
    self.font = [UIFont systemFontOfSize:14.5f];
    self.textColor = UIColor.whiteColor;
}

/**
 *  初始化子控件
 */
- (void)initTipLabelComponents{
    
}

/**
 *  布局
 */
- (void)makeConstrains{

}

- (void)drawTextInRect:(CGRect)rect {
    [super drawTextInRect:UIEdgeInsetsInsetRect(rect, self.textInsets)];
}

- (void)sizeToFit{
    [super sizeToFit];
    CGRect frame = self.frame;
    CGFloat width = CGRectGetWidth(self.bounds) + self.textInsets.left + self.textInsets.right;
    frame.size.width = width > self.maxWidth?self.maxWidth : width;
    frame.size.width = width < self.minWidth?self.minWidth : width;
    CGFloat height = CGRectGetHeight(self.bounds) + self.textInsets.top + self.textInsets.bottom;
    frame.size.height = MAX(height, self.minHeight);
    self.frame = frame;
}

/**
 *  窗口的大小
 */
- (CGRect)textRectForBounds:(CGRect)bounds limitedToNumberOfLines:(NSInteger)numberOfLines{
    bounds.size = [self.text boundingRectWithSize:CGSizeMake(self.maxWidth - self.textInsets.left - self.textInsets.right,CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.font} context:nil].size;
    if (bounds.size.width<self.minWidth) {
        bounds.size.width=self.minWidth;
    }
    return bounds;
}

@end
