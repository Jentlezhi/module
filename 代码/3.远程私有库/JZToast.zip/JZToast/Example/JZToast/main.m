//
//  main.m
//  JZToast
//
//  Created by jentlezhi on 06/15/2020.
//  Copyright (c) 2020 jentlezhi. All rights reserved.
//

@import UIKit;
#import "JZAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JZAppDelegate class]));
    }
}
