//
//  JZViewController.m
//  JZToast
//
//  Created by jentlezhi on 06/15/2020.
//  Copyright (c) 2020 jentlezhi. All rights reserved.
//

#import "JZViewController.h"
#import "JZToast.h"

@interface JZViewController ()

@end

@implementation JZViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    [JZToast messageToastWithMessage:@"开始执行弹框" completion:^{
        [JZToast errorToastWithMessage:@"错误" completion:^{
            [JZToast warningToastWithMessage:@"警告" completion:^{
                [JZToast successToastWithMessage:@"执行完成"];
            }];
        }];
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
