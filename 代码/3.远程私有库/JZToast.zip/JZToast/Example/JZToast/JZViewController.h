//
//  JZViewController.h
//  JZToast
//
//  Created by jentlezhi on 06/15/2020.
//  Copyright (c) 2020 jentlezhi. All rights reserved.
//

@import UIKit;

@interface JZViewController : UIViewController

@end
