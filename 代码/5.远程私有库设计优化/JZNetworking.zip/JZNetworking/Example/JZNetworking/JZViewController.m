//
//  JZViewController.m
//  JZNetworking
//
//  Created by Jentlezhi on 06/16/2020.
//  Copyright (c) 2020 Jentlezhi. All rights reserved.
//

#import "JZViewController.h"

@interface JZViewController ()

@end

@implementation JZViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
