# JZNetworking

[![CI Status](https://img.shields.io/travis/Jentlezhi/JZNetworking.svg?style=flat)](https://travis-ci.org/Jentlezhi/JZNetworking)
[![Version](https://img.shields.io/cocoapods/v/JZNetworking.svg?style=flat)](https://cocoapods.org/pods/JZNetworking)
[![License](https://img.shields.io/cocoapods/l/JZNetworking.svg?style=flat)](https://cocoapods.org/pods/JZNetworking)
[![Platform](https://img.shields.io/cocoapods/p/JZNetworking.svg?style=flat)](https://cocoapods.org/pods/JZNetworking)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

JZNetworking is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'JZNetworking'
```

## Author

Jentlezhi, juntaozhi@163.com

## License

JZNetworking is available under the MIT license. See the LICENSE file for more info.
