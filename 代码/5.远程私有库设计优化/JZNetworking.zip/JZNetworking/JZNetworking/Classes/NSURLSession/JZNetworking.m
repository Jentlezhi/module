//
//  JZNetworking.m
//  LibDependency_Example
//
//  Created by Jentle on 2020/6/16.
//  Copyright © 2020 Jentlezhi. All rights reserved.
//

#import "JZNetworking.h"
#import "AFNetworking.h"

@implementation JZNetworking

+ (NSURLSessionDataTask *)GET:(NSString *)URLString
                   parameters:(id)parameters
                   completion:(void(^)(BOOL failure,id responseObject))completion {
    
    return [[AFHTTPSessionManager manager] GET:URLString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        !completion?:completion(NO,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        !completion?:completion(YES,error);
    }];
}

+ (NSURLSessionDataTask *)POST:(NSString *)URLString
                   parameters:(id)parameters
                   completion:(void(^)(BOOL failure,id responseObject))completion {
    
    return [[AFHTTPSessionManager manager] POST:URLString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        !completion?:completion(NO,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        !completion?:completion(YES,error);
    }];
}

@end
