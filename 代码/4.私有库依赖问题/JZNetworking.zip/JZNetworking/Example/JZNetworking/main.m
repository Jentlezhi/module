//
//  main.m
//  JZNetworking
//
//  Created by Jentlezhi on 06/16/2020.
//  Copyright (c) 2020 Jentlezhi. All rights reserved.
//

@import UIKit;
#import "JZAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JZAppDelegate class]));
    }
}
