//
//  JZViewController.h
//  JZNetworking
//
//  Created by Jentlezhi on 06/16/2020.
//  Copyright (c) 2020 Jentlezhi. All rights reserved.
//

@import UIKit;

@interface JZViewController : UIViewController

@end
