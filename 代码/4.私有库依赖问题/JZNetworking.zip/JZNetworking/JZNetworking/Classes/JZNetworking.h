//
//  JZNetworking.h
//  LibDependency_Example
//
//  Created by Jentle on 2020/6/16.
//  Copyright © 2020 Jentlezhi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JZNetworking : NSObject

+ (NSURLSessionDataTask *)GET:(NSString *)URLString
                   parameters:(id)parameters
                   completion:(void(^)(BOOL failure,id responseObject))completion;

+ (NSURLSessionDataTask *)POST:(NSString *)URLString
                   parameters:(id)parameters
                    completion:(void(^)(BOOL failure,id responseObject))completion;

@end

NS_ASSUME_NONNULL_END
