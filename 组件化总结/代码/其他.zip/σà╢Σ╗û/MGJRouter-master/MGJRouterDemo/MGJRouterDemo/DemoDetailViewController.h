//
//  DemoDetailViewController.h
//  MGJRequestManagerDemo
//
//  Created by limboy on 3/20/15.
//  Copyright (c) 2015 juangua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoDetailViewController : UIViewController

@end
